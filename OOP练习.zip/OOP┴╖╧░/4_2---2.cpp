#include<iostream>
#include<string>
using namespace std;
class student
{
	public:
	student(string ="blank",float =0);
	void display();
	friend string max(student *p);
private:
	string number;
	float grade;
};
student::student(string num,float g)
{
number=num;
grade=g;
}
void student::display()
{
cout<<number<<":"<<grade<<endl;
}
string max(student *p)
{
float max=p->grade;
int flag;
for(int i=0;i<5;i++)
{
if(max<(p+i)->grade)
{
max=(p+i)->grade;
flag=i;
}
}
cout<<"max_grade="<<max<<endl;
return (p+flag)->number;
}
int main()
{
student person[]={
student("M2017001",87),
student("M2017002",90),
student("M2017003",80),
student("M2017004",97),
student("M2017005",93),
};
cout<<max(person)<<endl;
return 0;
}
