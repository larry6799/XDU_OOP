#include<iostream>
#include<string.h>
using namespace std;

class Student
{
	public:
		Student(char nm[18],int nu,int math,int english);	
		void Show();	
		static void ShowStatic();
	private:
		char name[18];	
		int num;	
		int mathScore;	
		int englishScore;	
		static int count;	
		static int mathTotalScore;	
		static int englishTotalScore;			
};


int Student::count=0;
int Student::mathTotalScore=0;
int Student::englishTotalScore=0;


Student::Student(char nm[18],int nu,int math,int english)
{
	count++;
	
	strcpy(name,nm);
	num=nu;
	mathScore=math;
	englishScore=english;

	mathTotalScore+=mathScore;
	englishTotalScore+=englishScore;
}

//��ʾ�������ݺ��� 
void Student::Show(){
	cout <<"name:"<<name<<endl;
	cout <<"num:"<<num<<endl;
	cout <<"mathScore:"<<mathScore<<endl;
	cout <<"englishScore:"<<englishScore<<endl;
}

//��ʾ��̬���ݺ��� 
void Student::ShowStatic()
{
	cout <<"count:"<<count<<endl;
	cout <<"mathTotalScore:"<<mathTotalScore<<endl;
	cout <<"englishTotalScore:"<<englishTotalScore<<endl;
}


int main()
{
	Student s[3]= {Student("Fiona",1001,95,100),Student("Larry",1002,98,96),Student("Jack",1003,96,95)};
	for(int i=0; i<3; i++)
	{
		s[i].Show();	
		cout <<endl;
	}
	cout<<endl;
	Student::ShowStatic();	
	return 0;
}

