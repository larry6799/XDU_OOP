#include<iostream>
#include<cstring>
using namespace std;

class  Person {
	public:
		Person(char na[],char ad[],char ci[],char pr[],char co[]);
		void change_name();
		void disp();
	private:
		char name[20];
		char address[50];
		char city[20];
		char province[30];
		char code[10];
		
};

Person::Person(char na[],char ad[],char ci[],char pr[],char co[]){
	strcpy(name,na);
	strcpy(address,ad);
	strcpy(city,ci);
	strcpy(province,pr);
	strcpy(code,co);
}

Person::disp(){
	cout<<"name:"<<name<<endl;
	cout<<"address:"<<address<<endl;
	cout<<"city:"<<city<<endl;
	cout<<"province:"<<province<<endl;
	cout<<"code:"<<code<<endl;
}

Person::change_name(){
	char name1[20];
	cout<<"�������޸ĺ������"<<endl;
	cin>>name1;
	strcpy(name,name1);
}

int main()
{
	Person p1("larry","zhi chun street","beijing","Bei Jing","100001");
	Person p2("fiona","xin hua street","anqing","An Hui","231400");
	p1.disp();
	p1.change_name();
	p1.disp();
}
	

