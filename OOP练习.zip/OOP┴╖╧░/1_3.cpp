#include<iostream>
#include<string>
using namespace std;
int main()
{
	string str;
	char temp;
	int i,j;
	cin>>str;
	for(i=0,j=str.size()-1;i<=j;i++,j--)
	{
		temp=str[i];
		str[i]=str[j];
		str[j]=temp;
	}
	cout<<str;
	return 0;
} 
