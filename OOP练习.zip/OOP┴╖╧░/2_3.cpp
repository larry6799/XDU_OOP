#include<iostream>
using namespace std;
class Rectangle{
	public:
		void set_rectangle();
		void volume();
		void dis_rectangle();
	private:
		double length;
		double width;
		double height;
		double v;
	
};
int main()
{
	Rectangle r1,r2,r3;
	r1.set_rectangle();
	r1.volume();
	r1.dis_rectangle();
	r2.set_rectangle();
	r2.volume();
	r2.dis_rectangle();
	r3.set_rectangle();
	r3.volume();
	r3.dis_rectangle();
	return 0;
}

void Rectangle::set_rectangle(){
	cout<<"�����볤���εĳ�����"<<endl;
	cin>>length>>width>>height;
} 

void Rectangle::volume(){
	v=length*width*height;
} 

void Rectangle::dis_rectangle(){
	cout<<"�˳���������Ϊ"<<v<<endl;
} 
