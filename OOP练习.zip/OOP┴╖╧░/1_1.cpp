#include <iostream>
using namespace std;
int max(int a,int b,int c=0)
{
	return c>(a>b?a:b)?c:(a>b?a:b);
}
int main()
{
	int a,b,c,d,e;
	cin>>a>>b>>c;
	cout<<"max(a,b,c)="<<max(a,b,c)<<endl;
	cin>>d>>e;
	cout<<"max(d,e)="<<max(d,e)<<endl;
} 
