#include<iostream>
using namespace std;

class People
{
	public:
		People(int a,int h,int w):age(a),height(h),weight(w){
			num++;   
		}
		void Eating();	
		void Sporting();			
		void Sleeping();			
		void Show();
		static void ShowNum();	
	protected:
		int age;	
		int height;	
		int weight;	
		static int num;	
	

};

int People::num=0;	


void People::Eating(){
	weight++;
}

void People::Sporting()
{
	height++;
}

void People::Sleeping()
{
	age++;
	height++;
	weight++;
}

void People::Show() 	 
{
	cout <<"age: "<<age<<"��"<<endl;
	cout <<"height: "<<height<<"����"<<endl;
	cout <<"weight: "<<weight<<"�н�"<<endl;
}

void People::ShowNum() 	
{
	cout <<"����"<<num<<"��"<<endl;
}

int main()
{
	People p1(18,175,130),p2(20,180,150);
	People::ShowNum();
	cout<<endl;
	p1.Show();
	p2.Show();	
	
	cout<<endl<<endl;	
	p1.Eating();   
	p1.Sporting(); 
	p2.Sleeping();
	p1.Show(); 
	p2.Show();     	
	return 0;
}

