#include<iostream>
#include<cstring>
using namespace std;
class Student
{
public:
    Student(string n,double s):num(n),score(s){}   
    void show();
    friend void max(Student *s);
private:
    string num;
    double score;
};

void max(Student *s)
{
    double max=s->score;
    int k=0;
    for(int i=0;i<5;i++)
    {
        if(max<(s+i)->score){
			max=(s+i)->score;
			k=i;
		}
    }
    cout<<"��߳ɼ�Ϊ:"<<max<<" ,��ѧ��ѧ��:"<<s[k].num;
}

int main()
{
    Student stu[5]={Student("A001",92),Student("A002",95),Student("A003",97.5),
					Student("A004",96.9),Student("A005",97.4)};
    Student *p=&stu[0];  
    max(p);
    return 0;
}


