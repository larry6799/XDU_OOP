#include<iostream>
using namespace std;
class Matrix{
	public:
		Matrix();
		friend istream&operator>>(istream&,Matrix&);
		friend ostream&operator<<(ostream&,Matrix&);
	private:
		int m[2][3];
}; 

Matrix::Matrix(){
	for(int i=0;i<2;i++)
		for(int j=0;j<3;j++)
			m[i][j]=0;
}

istream&operator>>(istream&input,Matrix&m){
	cout<<"������2��3�еľ���"<<endl;
	for(int i=0;i<2;i++)
		for(int j=0;j<3;j++)
			input>>m.m[i][j]; 
	return input;
}

ostream&operator<<(ostream&output,Matrix&m){
	cout<<"�����2��3�еľ���"<<endl;
	for(int i=0;i<2;i++){
		for(int j=0;j<3;j++){
			output<<m.m[i][j]<<" "; 
		}
		cout<<endl;	
	}
		
	return output;
}

int main(){
	Matrix a;
	cin>>a;
	cout<<a;
}
