#include<iostream>
using namespace std;
class  Date
{
	public:
		void set_date(){
			cin>>year>>month>>day;
		}
		void dis_date(){
			cout<<year<<"��"<<month<<"��"<<day<<"��"<<endl; 
		}
	private:
		int year;
		int month;
		int day; 
} ;

int main()
{
	Date date1;
	date1.set_date();
	date1.dis_date();
	return 0;
}
