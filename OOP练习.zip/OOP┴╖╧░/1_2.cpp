#include<iostream>
using namespace std;
int main()
{
	void sort3(int &,int &,int &);
	int a,b,c;
	cin>>a>>b>>c;
	sort3(a,b,c);
	cout<<a<<" "<<b<<" "<<c<<endl;
	return 0;
	
} 

void change(int &m,int &n)
{
	int temp;
	temp=m;
	m=n;
	n=temp;
}
void sort3(int &a,int &b,int &c)
{
	if(a>b) change(a,b);
	if(a>c)	change(a,c);
	if(b>c)	change(b,c);	
} 
