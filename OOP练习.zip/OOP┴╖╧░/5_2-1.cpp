#include<iostream>
#include<cstring>
using namespace std;

class Teacher{
	public:
		Teacher(string n,int a,char s,string t,string ad,string p);
		void disp();
	protected:
		string name;
		int age;
		char sex; 
		string title;
		string address;
		string phone;
};

Teacher::Teacher(string n,int a,char s,string t,string ad,string p):
	name(n),age(a),sex(s),title(t),address(ad),phone(p){}

void Teacher::disp(){
	cout<<"name: "<<name<<endl;
	cout<<"age: "<<age<<endl;
	cout<<"sex: "<<sex<<endl;
	cout<<"title: "<<title<<endl;
	cout<<"address: "<<address<<endl;
	cout<<"phone" <<phone<<endl;
}

class Cadre{
	public:
		Cadre(string n,int a,char s,string po,string ad,string p);
		void disp();
	protected:
		string name;
		int age;
		char sex; 
		string post;
		string address;
		string phone;
};

Cadre::Cadre(string n,int a,char s,string po,string ad,string p):
	name(n),age(a),sex(s),post(po),address(ad),phone(p){}

void Cadre::disp(){
	cout<<"name: "<<name<<endl;
	cout<<"age: "<<age<<endl;
	cout<<"sex: "<<sex<<endl;
	cout<<"post: "<<post<<endl;
	cout<<"address: "<<address<<endl;
	cout<<"phone" <<phone<<endl;
}

class Teacher_Cadre:public Teacher,public Cadre{
	public:
		Teacher_Cadre(string n,int a,char s,string t,string ad,string p,string po,double w);
		void disp_1();
	private:
		double wages;
};

Teacher_Cadre::Teacher_Cadre(string n,int a,char s,string t,string ad,string p,string po,double w):
	Teacher(n,a,s,t,ad,p),Cadre(n,a,s,po,ad,p),wages(w){}

void Teacher_Cadre::disp_1(){
	Teacher::disp();
	cout<<"post: "<<Cadre::post<<endl;
	cout<<"wages: "<<wages<<endl;
}
int main(){
	Teacher_Cadre tc("jnk",50,'m',"ghjbkk","xian","768696989","profe",12444.5);
	cout<<"��ʦ���θɲ��Ļ�����Ϣ���£�"<<endl; 
	tc.disp_1();
}


