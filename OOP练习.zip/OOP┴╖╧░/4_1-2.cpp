#include<iostream>
using namespace std;
class Complex{
	public:
		Complex(){real=0;imag=0;}
		Complex(double r,double i){real=r;imag=i;}
		friend Complex operator * (Complex &c1,Complex &c2);
		friend Complex operator / (Complex &c1,Complex &c2);
		void disp();
	private:
		double real;
		double imag;	
}; 

Complex operator * (Complex &c1,Complex &c2){
	return Complex(c1.real*c2.real-c1.imag*c2.imag,c1.imag*c2.real+c1.real*c2.imag);
/*	Complex c;
	c.real=c1.real*c2.real-c1.imag*c2.imag;
	c.imag=c1.imag*c2.real+c1.real*c2.imag;
	return c;*/
}

Complex operator / (Complex &c1,Complex &c2){
	return Complex(
		(c1.real*c2.real+c1.imag*c2.imag)/(c2.real*c2.real+c2.imag*c2.imag),
		(c1.imag*c2.real-c1.real*c2.imag)/(c2.real*c2.real+c2.imag*c2.imag)
	);
/*	Complex c;
	c.real=(c1.real*c2.real+c1.imag*c2.imag)/(c2.real*c2.real+c2.imag*c2.imag);
	c.imag=(c1.imag*c2.real-c1.real*c2.imag)/(c2.real*c2.real+c2.imag*c2.imag);
	return c;*/
}

void Complex::disp(){
	cout<<"("<<real<<","<<imag<<"i)"<<endl;
} 

int main(){
	double a,b,c,d;
	cout<<"��ֱ�������������ʵ�����鲿��"<<endl;
	cin>>a>>b>>c>>d;
	Complex c1(a,b),c2(c,d);
	cout<<"c1*c2=";
	(c1*c2).disp();
	cout<<"c1/c2=";
	(c1/c2).disp();
	return 0;
	
}
