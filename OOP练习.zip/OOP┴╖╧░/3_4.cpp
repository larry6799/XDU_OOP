#include <iostream>
#include <string.h>
using namespace std;
class Dog
{
public:
	Dog(char*,int,char*,float);
	void ShowName();
	void ShowAge();
	void ShowSex();
	void ShowWeight();
private:
	char name[20];
	int age;
	char sex[8];
	float weight;
};
 
Dog::Dog(char* _name,int _age,char* _sex,float _weight)
{
	strcpy(name,_name);
	age=_age;
	strcpy(sex , _sex);
	weight=_weight;
}
 
void Dog::ShowAge()
{
	cout<<"age:"<<age<<endl;
}
 
void Dog::ShowName()
{
	cout<<"name:"<<name<<endl;
}
 
void Dog::ShowSex()
{
	cout<<"sex:"<<sex<<endl;	
}
 
void Dog::ShowWeight()
{
	cout<<"weight:"<<weight<<"kg"<<endl;
}
 
 
int main()
{
	char _name[20]; int _age; char _sex[8]; float _weight;
	cin>>_name>>_age>>_sex>>_weight;
	Dog mydog(_name,_age,_sex,_weight);
	cout<<"This is my dog:"<<endl;
	
	//�ö���ָ�������������
	Dog (*p)=&mydog;
	(*p).ShowName();
	p->ShowAge();
	(*p).ShowSex();
	p->ShowWeight();
	
	return 0;
}

