#include<iostream>
using namespace std;
class  Date
{
	public:
		void set_date();
		void dis_date();
	private:
		int year;
		int month;
		int day; 
} ;

int main()
{
	Date date1;
	date1.set_date();
	date1.dis_date();
	return 0;
}

void Date::set_date(){
	cin>>year>>month>>day;
}
void Date::dis_date(){
	cout<<year<<"��"<<month<<"��"<<day<<"��"<<endl; 
}
